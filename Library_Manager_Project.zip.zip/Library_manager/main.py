
# main.py
from models import LibraryItem, Book, Member, Magazine, DVD  # TODO: also import Magazine, DVD
book = Book("Python 101", 1, "A. Rao")
magazine = Magazine("Tech Today", 2, 15)
dvd = DVD("Inception", 3, 148)
alice = Member("Alice", 101)
bob = Member("Bob", 102, max_items=1)
# 1. Borrowing with error handling
try:
    alice.borrow(book)
    print("Alice borrowed:", book.describe())
    bob.borrow(book)  # should fail: already borrowed
except ValueError as e:
    print("Could not borrow:", e)
try:
    bob.borrow(magazine)
    print("Bob borrowed:", magazine.describe())
except ValueError as e:
    print("Could not borrow:", e)
try:
    bob.borrow(dvd)
except ValueError as e:
    print("Could not borrow:", e)

# Scenario B: Bob tries to return Alice's book
try:
    bob.return_item(book)
except ValueError as e:
    print("Return error:", e)

    # Scenario C: Alice returns the book after 3 days
try:
    fee = alice.return_item(book, 3)
    print("Alice returned the book. Late fee: Rs", fee)
except ValueError as e:
    print("Return error:", e)

# 2. TODO: trigger the borrow-limit error and the not-borrowed error, catching each
# 3. Polymorphism: one loop, no type checks
items = [book, magazine, dvd]  # TODO: add the magazine and the DVD
for item in items:  # no type checks        
    print(item.describe(), "-> late fee for 3 days: Rs", item.late_fee(3))
# 4. Class attribute shared by all objects
print("Total items created:", LibraryItem.total_items)

# 5. Encapsulation demonstration
try:
    print(book.__available)
except AttributeError as e:
    print("Encapsulation:", e)

print("Availability through method:", book.is_available())
